package br.com.inf3im.priceresearch;
//Pesquisar FILTRAR usuario,produto...

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> implements Filterable {
    public static final String TAG = "Product Adapter";

    // definir escutadores/ouvintes de clique na tela
    private  View.OnClickListener mOnClickListener;
    private  View.OnLongClickListener mOnLongClickListener; //clique longo

    private Context mContext;

    //definir objetos de lista (SELECT = list<Product> listAllProducts(Context mContext))
    private List<Product> mProductList;
    // listar reserva para dar agilidade quando aplicar filtro
    private List<Product> mProductListFull;
    // o objeto mProductListFull permite que não seja feito um acesso ao banco de dados
    // operação com banco de dados custa 'fazer acesso ao banco de dados'

    // objeto para exibir o total da compra
    private TextView mTextViewTotalPrice;

    //criar o construtor da classe ProductActAdapter


    public ProductAdapter(Context mContext, List<Product> mProductList, TextView mTextViewTotalPrice) {
        this.mContext = mContext;
        this.mProductList = mProductList;
        this.mTextViewTotalPrice = mTextViewTotalPrice;
    }

    // <funcionalidade para trocar a cor do preço> que depende de uma avaliação
    // cor=f(rating) y = f(x)
    //funcionalidade = função = metodo =ação
    //trocar a cor é uma regra de negocio - o codigo abaixo deve estar em outra classe
    // isso deve ser feito para manter o codigo limpo (tecnico CLEAN CODE)
    public String setPriceColor(double vRating){
        if (vRating < 3 ){
            return "#BF0404"; //VERMELHO

        } else {
            return "#000000"; //PRETO

        }

    }

    @Override
    public Filter getFilter() {
        return null;
    }

    @NonNull
    @Override
    public ProductAdapter.ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAdapter.ProductViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {

        // essa subclasse é responsavel por ativar os elementos
        // de tela com o codigo java
        //aqui teremos os elementos do CARDVIEW
        private final ImageView mImageViewProduct;
        private final TextView mTextViewItemProductName;
        private final TextView getmTextViewItemProductPrice;
        private final RatingBar mRatingBarItemProductStar;
        private final Button mButtonProductAdd;
        private final Button mButtonProductRemove;
        private final Button mButtonProductQuantity;
        //variaveis para controlar quantidade e o preço total da compra
        int vQuantity=0;      // letra V variaveis e M objeto
        double vTotalPrice=0.0;

        // uma regra de negocio para totalizar o valor da conta
        //Não deve ser feito aqui-boa pratica de programação CLEAN CODE

        private void showTotalPrice(){
            vTotalPrice = 0.0;
            //laço de repetiçao  for  // evitar repetição de codigo
            for(int i=0 ; i <= mProductList.size()-1 ; i++){
                vTotalPrice = vTotalPrice + mProductList.get(i).getPrice() * mProductList.get(i).getUnit();

            }

            NumberFormat mNumberFormat = NumberFormat.getCurrencyInstance(new Locale("pt" , "BR"));
            String mStringValue = mNumberFormat.format(vTotalPrice);
            mTextViewTotalPrice.setText(mStringValue);

        }


        // classe interna para escutar/ouvur o clique no botão de adicionar produto
        public class ClickMyButoonAdd implements View.OnClickListener{

            @Override
            public void onClick(View v) {
                vQuantity = mProductList.get(getAdapterPosition()).getUnit() +1;
                mButtonProductQuantity.setText("" +vQuantity);
                mProductList.get(getAdapterPosition()).setUnit(vQuantity);
            }
        }


        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
